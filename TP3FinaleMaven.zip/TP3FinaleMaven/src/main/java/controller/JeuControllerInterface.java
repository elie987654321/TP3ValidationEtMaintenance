package controller;

import javafx.stage.Stage;

import java.io.IOException;

public interface JeuControllerInterface {
    public void start(Stage primaryStage) throws IOException ;
}
