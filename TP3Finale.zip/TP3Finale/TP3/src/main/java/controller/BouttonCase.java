package controller;

import javafx.scene.control.Button;

public class BouttonCase extends Button {
    private int ligne;

    private int range;

    public int getLigne() {
        return ligne;
    }

    public void setLigne(int ligne) {
        this.ligne = ligne;
    }

    public int getRange() {
        return range;
    }

    public void setRange(int range) {
        this.range = range;
    }
}
